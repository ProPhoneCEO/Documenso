import DocumentPage, { loader } from '~/routes/_authenticated+/documents.$id._index';

export { loader };

export default DocumentPage;
