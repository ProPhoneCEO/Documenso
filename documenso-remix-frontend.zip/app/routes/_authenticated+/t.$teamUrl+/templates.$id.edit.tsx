import TemplateEditPage, { loader } from '~/routes/_authenticated+/templates.$id.edit';

export { loader };

export default TemplateEditPage;
