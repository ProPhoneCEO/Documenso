import TemplatePage, { loader } from '~/routes/_authenticated+/templates.$id._index';

export { loader };

export default TemplatePage;
