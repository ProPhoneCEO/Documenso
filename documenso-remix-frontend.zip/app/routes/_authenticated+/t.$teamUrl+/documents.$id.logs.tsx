import DocumentLogsPage, { loader } from '~/routes/_authenticated+/documents.$id.logs';

export { loader };

export default DocumentLogsPage;
