import DocumentEditPage, { loader } from '~/routes/_authenticated+/documents.$id.edit';

export { loader };

export default DocumentEditPage;
