import TemplatesPage, { meta } from '~/routes/_authenticated+/templates._index';

export { meta };

export default TemplatesPage;
