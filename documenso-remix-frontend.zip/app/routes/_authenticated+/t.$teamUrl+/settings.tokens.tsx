import ApiTokensPage from '~/routes/_authenticated+/settings+/tokens';

export default ApiTokensPage;
