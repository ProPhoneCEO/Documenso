import DocumentsPage, { meta } from '~/routes/_authenticated+/documents._index';

export { meta };

export default DocumentsPage;
