export const EmbedPaywall = () => {
  return (
    <div>
      <h1>Paywall</h1>
    </div>
  );
};
